exports.id=361,exports.ids=[361],exports.modules={306:(a,b,c)=>{"use strict";c.d(b,{O8:()=>j,nm:()=>l,v:()=>i,zv:()=>h});var d=c(5092),e=c(671),f=c(971),g=c(8524);async function h(a){if(!(0,e.Lk)()){var b;let c=(0,d.cN)(a.userMessage,a.workspace.selectedNews,a.workspace.thoughtBoard);return{assistantMessage:c.content,suggestions:c.suggestion?[{id:(b=c.suggestion).id,type:b.coreIdea?"core_opinion":"main_thread",title:b.headline||"可应用建议",description:b.coreIdea||b.mainLine||"保留这条建议作为写作参考。",applyPayload:{topic:b.mainLine,targetReader:b.targetReader,writingAngle:b.writingAngle,stance:b.stance,coreIdea:b.coreIdea,supportReasons:b.supportReasons,titles:b.outlineTitle?[b.outlineTitle]:void 0}}]:[],fallback:"mock"}}let c=await k(b=>[{role:"system",content:f.FQ},{role:"user",content:JSON.stringify({retryInstruction:b>0?"上一次返回没有通过 JSON 或 schema 校验。请只返回符合格式的严格 JSON。":void 0,workspace:l(a.workspace),recentMessages:a.messages.slice(-10).map(a=>({role:a.role,content:a.content})),userMessage:a.userMessage},null,2)}],a=>g.wX.parse(a)),h={assistantMessage:c.assistantMessage,suggestions:c.suggestions.map(a=>({...a,id:a.id||(0,d.sX)("sug")}))};return g.Bn.parse(h)}async function i(a){if(!(0,e.Lk)())return{thoughtBoard:a.workspace.thoughtBoard,fallback:"mock"};let b=function(a,b){let c=b.thoughtBoard,d=b.selectedNews.map(a=>a.news.id),e=new Set(d),f=a.mainNewsId&&e.has(a.mainNewsId)?a.mainNewsId:c.mainNewsId&&e.has(c.mainNewsId)?c.mainNewsId:d[0];return{topic:a.topic||c.topic,mainNewsId:f,supportingNewsIds:a.supportingNewsIds.filter(a=>e.has(a)&&a!==f),targetReader:a.targetReader||c.targetReader,writingAngle:a.writingAngle||c.writingAngle,stance:a.stance||c.stance,coreIdea:a.coreIdea||c.coreIdea,supportReasons:a.supportReasons.length?a.supportReasons:c.supportReasons,titles:a.titles.length?a.titles:c.titles,openQuestions:a.openQuestions.length?a.openQuestions:c.openQuestions}}((await k(b=>[{role:"system",content:f.iC},{role:"user",content:JSON.stringify({retryInstruction:b>0?"上一次返回没有通过 JSON 或 schema 校验。请只返回 { thoughtBoard: ... } 严格 JSON。":void 0,trigger:a.trigger,workspace:l(a.workspace)},null,2)}],a=>g.Op.parse(a))).thoughtBoard,a.workspace);return{thoughtBoard:g.J_.parse(b)}}async function j(a){if(!(0,e.Lk)())return{outline:(0,d.O8)(a.outline,a.workspace.selectedNews,a.thoughtBoard),changeSummary:"使用 mock fallback 优化了未锁定大纲节点。",fallback:"mock"};let b=await k(b=>[{role:"system",content:f.tz},{role:"user",content:JSON.stringify({retryInstruction:b>0?"上一次返回没有通过 JSON 或 schema 校验。请严格保留 locked=true 节点，并只返回指定 JSON。":void 0,workspace:l(a.workspace),thoughtBoard:a.thoughtBoard,outline:a.outline},null,2)}],a=>g._u.parse(a)),c=function(a,b,c){let e=new Set(c),f=a.sections.map((a,c)=>({id:a.id||b.sections[c]?.id||(0,d.sX)("sec"),title:a.sectionTitle,purpose:a.sectionGoal,keyPoints:a.keyPoints,relatedNewsIds:a.relatedNewsIds.filter(a=>e.has(a)),aiAdvice:a.writingTips,locked:!1})),g=new Set,h=new Map(f.map(a=>[a.id,a])),i=b.sections.map((a,b)=>{if(a.locked)return g.add(a.id),a;let c=h.get(a.id);if(c)return g.add(c.id),{...c,id:a.id,locked:!1};let d=f[b];return d&&!g.has(d.id)?(g.add(d.id),{...d,id:a.id,locked:!1}):a});for(let a of f){if(i.length>=5)break;g.has(a.id)||i.push(a)}return{recommendedTitle:a.recommendedTitle,intro:a.intro,sections:i.length?i:b.sections,ending:a.ending,readerTakeaway:a.readerTakeaway,version:b.version+1,updatedAt:new Date().toISOString()}}(b.outline,a.outline,a.workspace.selectedNews.map(a=>a.news.id));return{outline:g.OR.parse(c),changeSummary:b.changeSummary}}async function k(a,b){let c;for(let d=0;d<2;d+=1)try{let c=await (0,e.tK)(a(d),{json:!0});return b(c)}catch(a){c=a}throw c instanceof Error?c:Error("DeepSeek JSON call failed.")}function l(a){return{workspaceName:a.workspaceName,status:a.status,selectedNews:a.selectedNews.map(a=>({id:a.news.id,title:a.news.title,translatedTitle:a.news.translatedTitle,source:a.news.source,publishedAt:a.news.publishedAt,summary:a.news.summary,keywords:a.news.keywords,importanceScore:a.news.importanceScore,aiSummary:a.news.aiSummary,whyImportant:a.news.whyImportant,writingAngles:a.news.writingAngles,role:a.role,note:a.note})),thoughtBoard:a.thoughtBoard,outline:a.outline,materialDirty:a.materialDirty,ideaDirty:a.ideaDirty}}},671:(a,b,c)=>{"use strict";c.d(b,{DR:()=>g,Lk:()=>e,tK:()=>f});class d extends Error{constructor(a,b,c){super(a),this.code=b,this.status=c,this.name="DeepSeekClientError"}}function e(){return!!process.env.DEEPSEEK_API_KEY}async function f(a,b={}){var c=await h(a,{...b,json:!0});let e=c.trim().replace(/^```json\s*/i,"").replace(/^```\s*/i,"").replace(/\s*```$/i,"").trim();try{return JSON.parse(e)}catch(a){throw new d("DeepSeek response is not valid JSON.","json_parse_failed")}}async function g(a,b,c={}){let e=process.env.DEEPSEEK_API_KEY;if(!e)throw new d("DEEPSEEK_API_KEY is not configured.","missing_api_key");let f=i(process.env.DEEPSEEK_BASE_URL||"https://api.deepseek.com"),h=process.env.DEEPSEEK_MODEL||"deepseek-v4-pro",k=await fetch(`${f}/chat/completions`,{method:"POST",headers:{Authorization:`Bearer ${e}`,"Content-Type":"application/json"},body:JSON.stringify({model:h,messages:a,temperature:c.temperature??.35,stream:!0,reasoning_effort:"high",extra_body:{thinking:{type:"enabled"}}})});if(!k.ok||!k.body)throw new d(`DeepSeek stream request failed with status ${k.status}.`,"request_failed",k.status);await j(k.body,b)}async function h(a,b){let c=process.env.DEEPSEEK_API_KEY;if(!c)throw new d("DEEPSEEK_API_KEY is not configured.","missing_api_key");let e=i(process.env.DEEPSEEK_BASE_URL||"https://api.deepseek.com"),f=process.env.DEEPSEEK_MODEL||"deepseek-v4-pro",g=await fetch(`${e}/chat/completions`,{method:"POST",headers:{Authorization:`Bearer ${c}`,"Content-Type":"application/json"},body:JSON.stringify({model:f,messages:a,temperature:b.temperature??.35,...b.json?{response_format:{type:"json_object"}}:{}})}),h=await g.json().catch(()=>void 0);if(!g.ok)throw new d(`DeepSeek request failed with status ${g.status}.`,"request_failed",g.status);let j=h?.choices?.[0]?.message?.content;if("string"!=typeof j||!j.trim())throw new d("DeepSeek returned an empty response.","invalid_response");return j}function i(a){return a.replace(/\/+$/,"")}async function j(a,b){let c=a.getReader(),d=new TextDecoder,e="";for(;;){let{value:a,done:f}=await c.read();if(f)break;let g=(e+=d.decode(a,{stream:!0})).split(/\n\n/);for(let a of(e=g.pop()??"",g))for(let c of a.split(/\r?\n/).filter(a=>a.startsWith("data:")).map(a=>a.replace(/^data:\s?/,"").trim())){if(!c||"[DONE]"===c)continue;let a=JSON.parse(c),d=a?.choices?.[0]?.delta,e=d?.reasoning_content,f=d?.content;"string"==typeof e&&e&&b({type:"reasoning",delta:e}),"string"==typeof f&&f&&b({type:"content",delta:f})}}}},971:(a,b,c)=>{"use strict";c.d(b,{$L:()=>l,D9:()=>e,FQ:()=>d,PU:()=>j,Qx:()=>k,iC:()=>f,t4:()=>m,tz:()=>g,uv:()=>i,vE:()=>h});let d=`
你是「雷霆嘎巴写稿器」里的 AI 科技公众号写作编辑。
你的职责是启发用户理清写作方向，而不是直接替用户写完整文章。
不要生成完整正文。不要直接替用户定稿。
你可以解释新闻、分析新闻关系、提出写作角度、追问用户、给出建议。
任何会影响思路板或大纲的内容，都必须作为 suggestions 返回，由用户确认后应用。

回复风格要求：
- 简明扼要，像聊天一样自然，不要长篇大论。
- 禁止使用 Markdown 格式（不要用 **、##、- 列表、> 引用等）。
- 不要用"首先/其次/最后""综上所述""值得注意的是"等套话。
- 先给结论，再简短解释，不超过 3-4 个自然段。
- 提出的建议用自然语言表达，不要编号。

必须输出 JSON：
{
  "assistantMessage": "给用户看的回复（纯文本，无 Markdown）",
  "suggestions": [
    {
      "id": "string",
      "type": "core_opinion | main_thread | target_reader | writing_angle | outline_patch | reference",
      "title": "建议标题",
      "description": "建议说明",
      "applyPayload": {}
    }
  ]
}
`.trim(),e=`
你是「雷霆嘎巴写稿器」里的 AI 科技公众号写作编辑。
你的职责是启发用户理清写作方向，而不是直接替用户写完整文章。
不要生成完整正文。不要直接替用户定稿。不要输出 JSON。
你可以解释新闻、分析新闻关系、提出写作角度、追问用户、给出建议。
任何会影响思路板或大纲的内容，都要表达为”建议用户确认后应用”的口吻。

回复风格要求：
- 简明扼要，像微信聊天一样自然。
- 禁止使用任何 Markdown 格式符号（不要用 ** 加粗、## 标题、- 列表、> 引用、数字编号列表等）。
- 不要用”首先/其次/最后””综上所述””值得注意的是””在当今时代”等套话。
- 先给结论或判断，再简短展开，控制在 3-4 个自然段以内。
- 段落用空行分隔即可，不需要任何装饰符号。
- 可以追问用户，但一次只问 1-2 个最关键的。
`.trim(),f=`
你需要根据当前工作区新闻、用户选择、对话内容，更新结构化思路板。
请提炼：
- 当前选题 topic
- 主新闻 mainNewsId
- 辅助新闻 supportingNewsIds
- 目标读者 targetReader
- 写作角度 writingAngle
- 表达立场 stance
- 核心观点 coreIdea
- 支撑理由 supportReasons
- 可用标题 titles
- 待补充问题 openQuestions

不要生成完整正文。
只返回严格 JSON，不要 Markdown，不要代码块。
返回格式：
{
  "thoughtBoard": {
    "topic": "string",
    "mainNewsId": "string 或省略",
    "supportingNewsIds": ["string"],
    "targetReader": "string",
    "writingAngle": "string",
    "stance": "string",
    "coreIdea": "string",
    "supportReasons": ["string"],
    "titles": ["string"],
    "openQuestions": ["string"]
  }
}
`.trim(),g=`
你需要根据当前思路板和已有大纲，优化公众号文章大纲。
不要生成完整正文。
大纲要适合公众号文章，而不是论文提纲。
只优化 locked=false 的节点。
必须保留 locked=true 的节点，不要改标题、目的、要点、关联新闻或写作建议。
如果已有节点有 id，请尽量沿用 id。
必须输出严格 JSON，不要 Markdown，不要代码块。

每个大纲节点必须包含：
- id
- sectionTitle
- sectionGoal
- keyPoints
- relatedNewsIds
- writingTips
- locked

返回格式：
{
  "outline": {
    "recommendedTitle": "string",
    "intro": "string",
    "sections": [
      {
        "id": "string",
        "sectionTitle": "string",
        "sectionGoal": "string",
        "keyPoints": ["string"],
        "relatedNewsIds": ["string"],
        "writingTips": "string",
        "locked": false
      }
    ],
    "ending": "string",
    "readerTakeaway": "string"
  },
  "changeSummary": "string"
}
`.trim(),h=`
你是「雷霆嘎巴写稿器」中的 AI 科技公众号写作编辑。
你的目标是帮助用户把确认后的大纲变成适合公众号阅读的正文。

任务：
- 只生成当前 section 对应的正文块，不要生成整篇文章。
- 不要写成论文，不要写成新闻通稿，不要写得太像 AI 总结。
- 段落要短，适合手机阅读，语言清晰、自然、有观点。
- 保留用户大纲中的核心观点。
- 不要编造新闻事实。所有事实必须来自 workspace.selectedNews 或 outline.relatedNewsIds。
- 如果信息不足，用谨慎表达。
- 输出必须是 JSON，不要 Markdown 代码块。

正文风格：
- 小标题清晰。
- 段落不要太长。
- 重点可以加粗。
- 可以使用引用句。
- 可以适当加入转场。
- 不要过度营销，不要夸张标题党。

返回格式：
{
  "blocks": [
    {
      "id": "string",
      "outlineSectionId": "string",
      "type": "heading | paragraph | quote | list",
      "content": "string",
      "status": "generated",
      "locked": false,
      "updatedAt": "ISO string"
    }
  ]
}
`.trim(),i=`
你是「雷霆嘎巴写稿器」中的 AI 科技公众号写作编辑。
你的目标是只改写用户指定的一个 ArticleBlock，不要影响其他正文块。

要求：
- 只返回当前 block 的改写结果。
- locked=true 的内容不应该被改写。
- 不要编造新闻事实。事实只能来自 workspace.selectedNews、outline 或当前 block。
- instruction 决定改写方向：expand、shorten、wechat_style、reduce_ai_tone、add_example、add_transition、custom。
- 如果是 add_example，但素材里没有足够事实，请使用谨慎的假设表达，不要硬编真实案例。
- 保留原有观点，不要把文章改成论文或新闻通稿。
- 语言适合公众号手机阅读，短段落、自然、有判断。
- 输出必须是 JSON，不要 Markdown 代码块。

返回格式：
{
  "block": {
    "id": "string",
    "outlineSectionId": "string",
    "type": "title | intro | heading | paragraph | quote | list | conclusion | cta",
    "content": "string",
    "status": "generated",
    "locked": false,
    "updatedAt": "ISO string"
  }
}
`.trim(),j=`
你是「雷霆嘎巴写稿器」中的 AI 科技公众号写作编辑。
你的目标是把确认后的大纲填充为结构化公众号文章草稿。

要求：
- 生成完整文章草稿，但默认只填充 empty 的正文块。
- 不要覆盖 locked=true 的 block。
- 不要覆盖用户已经 edited 的 block，除非输入明确 allowOverwriteEdited=true。
- 不要写成论文，不要写成新闻通稿，不要写得太像 AI 总结。
- 段落短，手机可读，小标题清晰，语言自然，有观点。
- 不要编造新闻事实。所有事实必须来自 workspace.selectedNews 或 outline.relatedNewsIds。
- 如果信息不足，用谨慎表达。
- 输出必须是 JSON，不要 Markdown 代码块。

返回格式：
{
  "blocks": [
    {
      "id": "string",
      "outlineSectionId": "string",
      "type": "title | intro | heading | paragraph | quote | list | conclusion | cta",
      "content": "string",
      "status": "generated",
      "locked": false,
      "updatedAt": "ISO string"
    }
  ]
}
`.trim(),k=`
你是「雷霆嘎巴写稿器」的公众号写作编辑。
你的任务是把已确认的大纲写成自然、清晰、适合公众号阅读的中文文章。
请直接输出正文内容。
不要输出解释。
不要输出 Markdown 语法。
不要使用 ** 加粗符号。
不要使用 ## 标题符号。
不要使用 --- 分割线。
不要使用机械列表，除非用户明确要求。
不要写成论文。
不要写成新闻通稿。
不要写成 AI 总结。
不要使用“首先、其次、最后”这种机械结构。
不要使用“综上所述”“值得注意的是”“在当今时代”等套话。
段落要短，但表达要自然。
可以有观点，但不要夸张。
不要编造新闻事实。
所有事实只能来自 workspace 中的新闻和 outline 中的信息。
如果事实不确定，用谨慎表达。
语言要像一个认真写公众号的真人作者。

请特别避免这种句子：
“这两条新闻放在一起看，其实是一个清晰的信号：**AI 产品正在从单点能力展示，进入真实任务的可执行阶段**。”

更自然的写法类似：
“把这几条新闻放在一起看，会发现一个变化：AI 产品不再只是展示某个单点能力，而是开始尝试接住真实任务。这个变化不算突然，但它带来的问题，比表面看起来复杂得多。”

最后输出只能是正文纯文本。
`.trim(),l=`
你是「雷霆嘎巴写稿器」的公众号写作编辑。
请根据用户给定的当前 section，只生成这一节的正文纯文本。
不要生成整篇文章。
不要输出解释。
不要输出 Markdown 语法。
不要使用 **、##、---。
不要使用“首先、其次、最后”“综上所述”“值得注意的是”“在当今时代”等套话。
不要编造新闻事实。
事实只能来自 workspace 新闻、outline 和当前 section。
如果信息不足，用谨慎表达。
语言要自然、短段落、有观点，像认真写公众号的真人作者。
最后输出只能是这一节正文纯文本。
`.trim(),m=`
你是「雷霆嘎巴写稿器」的公众号写作编辑。
你只改写用户选中的文字。
只返回改写后的文本。
不要返回解释。
不要返回 Markdown。
不要返回 JSON。
不要带“下面是改写后版本”等前后说明。
不要使用 **、##、---。
不要使用“首先、其次、最后”“综上所述”“值得注意的是”“在当今时代”等套话。
不要编造事实。
保留原意，按 instruction 调整表达。
语言要自然，像认真写公众号的真人作者。
`.trim()},5092:(a,b,c)=>{"use strict";c.d(b,{O8:()=>f,cN:()=>g,sX:()=>e});let d={targetReader:"目标读者",writingAngle:"写作角度",stance:"表达立场"};function e(a){return`${a}-${Math.random().toString(36).slice(2,9)}`}function f(a,b,c){var d,f;let g=function(a,b){let c=a.map(a=>a.news),d=a.find(a=>a.news.id===b.mainNewsId)?.news??c[0],f=function(a,b){let c=a.map(a=>a.news),d=a.find(a=>a.news.id===b.mainNewsId)?.news??c[0],f=a.map(a=>a.news.id);return 0===c.length?[{id:e("sec"),title:"先确定素材池",purpose:"明确要讨论的新闻范围，避免空泛开题。",keyPoints:["选择至少一条主新闻","补充一到三条辅助新闻","记录你想追问的问题"],relatedNewsIds:[],aiAdvice:"先不要急着生成正文，把素材关系确认清楚。",locked:!1}]:[{id:e("sec"),title:"用一个具体新闻打开问题",purpose:"让读者先看到一个清晰变化，而不是直接进入抽象判断。",keyPoints:[d?`主新闻：${d.title}`:"选出最能代表趋势的一条新闻","解释它和读者日常工作或决策的关系","提出文章要回答的核心问题"],relatedNewsIds:d?[d.id]:[],aiAdvice:"开头不宜堆信息，保留一个强问题即可。",locked:!1},{id:e("sec"),title:"把多条新闻归成一条主线",purpose:"从新闻罗列转向结构化解释，形成文章判断框架。",keyPoints:[b.topic||h(c),"找出共同变量：能力、入口、成本、场景或商业化","区分确定趋势和还未验证的部分"],relatedNewsIds:f.slice(0,3),aiAdvice:"这一节适合用并列案例，不要让每条新闻平均占篇幅。",locked:!1},{id:e("sec"),title:"分析对目标读者的真实影响",purpose:"把行业变化翻译成读者可感知的机会、风险和行动。",keyPoints:[b.targetReader?`围绕${b.targetReader}展开`:"先选择目标读者","说明哪些工作会被增强，哪些判断仍需人来完成","给出一到两个具体使用或观察建议"],relatedNewsIds:f.slice(1,4),aiAdvice:"避免泛泛说效率提升，最好写出一个具体工作场景。",locked:!1},{id:e("sec"),title:"给出你的判断与边界",purpose:"形成公众号文章的观点记忆点，让读者知道你到底怎么看。",keyPoints:[b.stance?`表达立场：${b.stance}`:"选择看好、质疑或中立分析",b.coreIdea||"补充一句核心观点","指出还需要等待验证的指标"],relatedNewsIds:f,aiAdvice:"结论可以鲜明，但要保留证据边界。",locked:!1}]}(a,b);return{recommendedTitle:b.titles[0]??(d?`从${d.keywords[0]}看 AI 产品的新拐点`:"先选几条新闻，让选题开始成型"),intro:d?`从「${d.title}」切入，用一个具体变化带出 AI 产品从能力展示走向任务闭环的趋势。`:"先用一条最有代表性的新闻开场，再把其他素材组织成一条可讨论的主线。",sections:f,ending:"收束到创作者或目标读者可以采取的行动：关注入口变化、验证真实效率、保留独立判断。",readerTakeaway:b.targetReader?`${b.targetReader}可以获得一套判断 AI 产品变化是否值得跟进的框架。`:"读者能看懂新闻背后的产品方向，并带走一个可复用的观察框架。",version:1,updatedAt:new Date().toISOString()}}(b,c),i=new Map(a.sections.filter(a=>a.locked).map(a=>[a.id,a])),j=g.sections.map((b,d)=>{var e,f;let g=a.sections[d];if(g?.locked)return g;let h=i.get(b.id);return h||{...b,id:g?.id??b.id,title:(e=b.title,(f=c).writingAngle?"产品分析"===f.writingAngle?e.replace("真实影响","产品机会").replace("判断与边界","产品判断与风险"):"职业启发"===f.writingAngle?e.replace("真实影响","个人能力影响").replace("判断与边界","行动建议"):"技术科普"===f.writingAngle?e.replace("主线","技术逻辑").replace("真实影响","使用门槛"):e:e),purpose:`${b.purpose}${c.targetReader?` 面向${c.targetReader}，减少泛泛而谈。`:""}`,aiAdvice:function(a,b){let c=a.targetReader?`面向${a.targetReader}`:"面向明确读者",d=a.writingAngle||"当前角度";return`${c}，用${d}语气处理「${b.title}」：先讲变化，再讲影响，最后给一个可执行判断。`}(c,b)}});return{...g,sections:j,recommendedTitle:c.titles[0]??`${c.topic||"AI 新闻"}：${c.coreIdea||"从热点到判断框架"}`,intro:function(a,b){let c=a.find(a=>a.news.id===b.mainNewsId)?.news??a[0]?.news;return c?`从「${c.title}」切入，先说明它为什么不是孤立事件，再把话题收束到「${b.topic||"AI 产品变化"}」。`:"先选择新闻素材，再从最有冲突感的一条新闻切入。"}(b,c),ending:"提醒风险"===(d=c).stance||"质疑"===d.stance?"结尾提醒读者区分演示能力和稳定价值：看清边界，再决定是否投入时间和资源。":"看好"===d.stance?"结尾给出积极判断：真正值得关注的不是单个工具，而是 AI 进入工作流后的长期复利。":"结尾回到判断框架：哪些变化已经发生，哪些还需要继续观察，读者下一步可以如何验证。",readerTakeaway:(f=c).targetReader?`${f.targetReader}将带走一套观察 AI 新闻的方法：看入口、看任务闭环、看是否创造真实效率。`:"读者将带走一套把 AI 热点转化为判断框架的方法。",version:a.version+1,updatedAt:new Date().toISOString()}}function g(a,b,c,f){var g;let j=c.topic||h(b.map(a=>a.news)),k=c.coreIdea||`这些素材可以合成一条主线：${j}，重点不是罗列新闻，而是解释变化如何影响具体人群。`,l=f?`已收到你的选择：${d[f.kind]}是「${f.value}」。这会让文章更容易聚焦，后续可以把案例筛选、标题语气和结尾建议都围绕这个选择收紧。`:function(a,b,c){let d=a.trim(),e=c.topic||h(b.map(a=>a.news));return/合成|组合|一篇|主线/.test(d)?`可以。它们共同指向一个趋势：${e}。建议不要按新闻时间线写，而是先提出一个变化，再用不同新闻分别证明「能力变化」「场景变化」和「读者影响」。`:/标题|题目/.test(d)?`标题可以把「新闻事实」和「读者收益」同时放进去。比如先用一个判断抓住注意力，再用副标题暗示这不是单条新闻解读，而是一篇趋势判断。`:/风险|问题|质疑/.test(d)?`可以加入风险视角：AI 产品现在最容易被高估的是演示效果，最需要验证的是稳定性、成本、上下文安全和真实工作流中的可控性。`:`我的建议是先把这组素材收束到一个可争论的问题：${e}。公众号文章不必追求覆盖所有信息，关键是让读者读完后多一个判断角度。`}(a,b,c);return{id:e("msg"),role:"assistant",createdAt:new Date().toISOString(),content:l,suggestion:{id:e("sug"),headline:"可应用建议",mainLine:k,targetReader:c.targetReader||i("targetReader",f)||"AI 产品经理",writingAngle:c.writingAngle||i("writingAngle",f)||"产品分析",stance:c.stance||i("stance",f)||"中立分析",coreIdea:function(a,b,c){let d=b.topic||h(a.map(a=>a.news)),e=i("targetReader",c)||b.targetReader||"内容读者",f=i("writingAngle",c)||b.writingAngle||"趋势判断";return`从${f}看，${d}。这件事对${e}的意义，是判断 AI 工具是否正在从“会回答”走向“能完成任务”。`}(b,c,f),supportReasons:0===(g=b).length?[]:g.slice(0,4).map(a=>{let b=a.news.keywords[0];return`${b}案例显示：${a.news.summary}`}),outlineTitle:function(a,b){let c=a[0]?.news;return c?[`AI 产品进入执行时代：${b||"趋势"}视角下的新机会`,`别只看模型参数，AI 工具真正的变化在工作流里`,`从${c.keywords[0]}新闻看下一波 AI 应用竞争`]:["选题还在发芽：先把素材放进工作区"]}(b,c.writingAngle||i("writingAngle",f))[0]}}}function h(a){if(0===a.length)return"从 AI 新闻中寻找一个值得展开的选题";let b=Object.entries(a.flatMap(a=>a.keywords).reduce((a,b)=>(a[b]=(a[b]??0)+1,a),{})).sort((a,b)=>b[1]-a[1]).slice(0,3).map(([a])=>a);return b.some(a=>a.includes("编程")||a.includes("Agent"))?"AI 编程工具正在从辅助补全走向任务执行":b.some(a=>a.includes("多模态"))?"多模态模型正在把内容理解和工作流连接起来":b.some(a=>a.includes("办公"))?"AI 办公工具正在从效率插件变成协作流程入口":`${b.join("、")||"AI 产品"}背后的新变化`}function i(a,b){return b?.kind===a?b.value:void 0}},6487:()=>{},8335:()=>{},8524:(a,b,c)=>{"use strict";c.d(b,{$v:()=>s,Bn:()=>h,Fi:()=>u,J_:()=>j,OR:()=>m,Op:()=>k,_u:()=>o,gN:()=>t,wX:()=>i});var d=c(657);let e=d.k5(["core_opinion","main_thread","target_reader","writing_angle","outline_patch","reference"]),f=d.Ik({id:d.Yj().min(1),type:e,title:d.Yj().min(1),description:d.Yj().min(1),applyPayload:d.g1(d.Yj(),d.L5()).default({})}),g=f.extend({id:d.Yj().min(1).optional()}),h=d.Ik({assistantMessage:d.Yj().min(1),suggestions:d.YO(f).default([])}),i=d.Ik({assistantMessage:d.Yj().min(1),suggestions:d.YO(g).default([])}),j=d.Ik({topic:d.Yj(),mainNewsId:d.Yj().optional(),supportingNewsIds:d.YO(d.Yj()).default([]),targetReader:d.Yj(),writingAngle:d.Yj(),stance:d.Yj(),coreIdea:d.Yj(),supportReasons:d.YO(d.Yj()).default([]),titles:d.YO(d.Yj()).default([]),openQuestions:d.YO(d.Yj()).default([])}),k=d.Ik({thoughtBoard:j}),l=d.Ik({id:d.Yj().min(1),title:d.Yj().min(1),purpose:d.Yj().min(1),keyPoints:d.YO(d.Yj()).default([]),relatedNewsIds:d.YO(d.Yj()).default([]),aiAdvice:d.Yj().min(1),locked:d.zM()}),m=d.Ik({recommendedTitle:d.Yj().min(1),intro:d.Yj().min(1),sections:d.YO(l).min(1),ending:d.Yj().min(1),readerTakeaway:d.Yj().min(1),version:d.ai().int().nonnegative(),updatedAt:d.Yj().min(1)}),n=d.Ik({id:d.Yj().min(1).optional(),sectionTitle:d.Yj().min(1),sectionGoal:d.Yj().min(1),keyPoints:d.YO(d.Yj()).default([]),relatedNewsIds:d.YO(d.Yj()).default([]),writingTips:d.Yj().min(1),locked:d.zM().default(!1)}),o=d.Ik({outline:d.Ik({recommendedTitle:d.Yj().min(1),intro:d.Yj().min(1),sections:d.YO(n).min(1),ending:d.Yj().min(1),readerTakeaway:d.Yj().min(1)}),changeSummary:d.Yj().min(1)}),p=d.k5(["title","intro","heading","paragraph","quote","list","conclusion","cta"]),q=d.k5(["empty","generated","edited"]),r=d.Ik({id:d.Yj().min(1),outlineSectionId:d.Yj().min(1),type:p,content:d.Yj(),status:q,locked:d.zM(),updatedAt:d.Yj().min(1)});d.Ik({id:d.Yj().min(1),name:d.Yj().min(1),description:d.Yj().min(1),paragraphStyle:d.Yj().min(1),headingStyle:d.Yj().min(1),quoteStyle:d.Yj().min(1),dividerStyle:d.Yj().min(1)}),d.Ik({outlineId:d.Yj().min(1),blocks:d.YO(r),selectedTemplateId:d.Yj().min(1),activeSectionId:d.Yj().optional(),status:d.k5(["empty","partial","generated","edited","exported"]),updatedAt:d.Yj().min(1)});let s=d.Ik({blocks:d.YO(r).min(1)}),t=d.Ik({block:r}),u=d.Ik({blocks:d.YO(r).min(1)})}};